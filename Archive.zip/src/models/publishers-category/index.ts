export interface PublishersCategory {
    id: number;
    name: string;
    created_at: string;
    updated_at: string;
}