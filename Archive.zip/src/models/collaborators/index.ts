export interface CollaboratorModel {
    first_name: string;
    last_name: string;
    email: string;
    role: string;
    user_id: number;
    updated_at: string;
    created_at: string;
    id: number
}